# Library Management System (Java)

A simple console-based Library Management System using Core Java and OOP.

## Features
- Add new books
- View all books
- Issue a book
- Return a book
- Preloaded sample books for testing

## Sample Data
- Book ID: 1, Title: Java Basics, Author: James Gosling
- Book ID: 2, Title: Effective Java, Author: Joshua Bloch
- Book ID: 3, Title: Clean Code, Author: Robert C. Martin

## How to Run
1. Clone the repository or download the ZIP
2. Open in any Java IDE or terminal
3. Compile and run:
   ```bash
   javac LibraryManagementSystem.java
   java LibraryManagementSystem
   ```

## Technologies Used
- Java
- OOP Concepts
